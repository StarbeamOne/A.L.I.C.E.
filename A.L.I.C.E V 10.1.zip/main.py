import json

# Define function to prompt the user for input and generate a response
def chat():
    # Load library from JSON file
    with open("library.json", encoding="utf-8") as f:
        library = json.load(f)

    # Load Steve's knowledge from JSON file
    with open("starbeam_info.json", encoding="utf-8") as f:
        starbeam_info = json.load(f)

    # Create list of questions
    questions = [pair["question"] for pair in library["pairs"]]
    questions.append("Exit program")

    print("A.L.I.C.E.: Hi, I'm A.L.I.C.E. How can I help you today?")
    while True:
        user_input = input("You: ")
        if not user_input.strip():
            print("A.L.I.C.E.: I'm sorry, you need to provide a query to continue.")
            continue

        if user_input.lower() == "exit program" or user_input == "7":
            print("A.L.I.C.E.: Goodbye!")
            break

        prompt = ""
        for pair in library["pairs"]:
            if user_input.lower() in pair["question"].lower():
                prompt += f"User: {user_input}\nA.L.I.C.E.: {pair['response']}\n"
                break
        else:
            if user_input.lower() == "what do you know about starbeam one?":
                prompt = f"User: {user_input}\nA.L.I.C.E.: {starbeam_info['technical_description']}\n"
            else:
                prompt = f"User: {user_input}\nA.L.I.C.E.: I'm sorry, I don't have an answer for that. Here are some available questions:\n"
                for i, question in enumerate(questions):
                    prompt += f"{i+1}. {question}\n"

        print("A.L.I.C.E.:", prompt)

# Run the chat function
if __name__ == "__main__":
    chat()
